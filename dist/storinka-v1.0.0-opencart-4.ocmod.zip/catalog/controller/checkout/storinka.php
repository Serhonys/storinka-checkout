<?php
namespace Opencart\Catalog\Controller\Extension\Storinka\Checkout;
/**
 * OpenCart 4.x port. Shipping and payment come from the core checkout models.
 * Orders are written with the 4.x column shape (method stored as JSON name/code).
 * The 3.x package remains the reference build for ocStore 3.0.4.1.
 */
class Storinka extends \Opencart\System\Engine\Controller {
	public function index(): void {
		$this->load->language('extension/storinka/checkout/storinka');
		if ((!$this->cart->hasProducts() && empty($this->session->data['vouchers'])) || (!$this->cart->hasStock() && !$this->config->get('config_stock_checkout')) || !$this->cart->hasMinimum()) {
			$this->response->redirect($this->url->link('checkout/cart', 'language=' . $this->config->get('config_language')));
			return;
		}
		$this->document->setTitle($this->language->get('heading_title'));
		$this->document->addStyle('extension/storinka/catalog/view/javascript/storinka/storinka.css');
		$this->document->addScript('extension/storinka/catalog/view/javascript/storinka/storinka.js');
		$base = 'language=' . $this->config->get('config_language');
		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_trust'] = $this->language->get('text_trust');
		$data['text_contact'] = $this->language->get('text_contact');
		$data['text_shipping'] = $this->language->get('text_shipping');
		$data['text_payment'] = $this->language->get('text_payment');
		$data['text_comment'] = $this->language->get('text_comment');
		$data['text_coupon'] = $this->language->get('text_coupon');
		$data['text_np'] = $this->language->get('text_np');
		$data['text_branch'] = $this->language->get('text_branch');
		$data['text_postomat'] = $this->language->get('text_postomat');
		$data['text_city'] = $this->language->get('entry_city');
		$data['text_street'] = $this->language->get('entry_address_1');
		$data['text_standard'] = $this->language->get('text_standard');
		$data['text_login'] = $this->language->get('text_login');
		$data['text_register'] = '';
		$data['button_confirm'] = $this->language->get('button_confirm');
		$data['standard'] = $this->url->link('checkout/checkout', $base . '&storinka_off=1');
		$data['logged'] = $this->customer->isLogged();
		$data['login_enabled'] = false;
		$data['register_enabled'] = false;
		$data['fields'] = [[
			'name' => 'firstname', 'label' => $this->language->get('entry_firstname'), 'type' => 'text', 'value' => $this->customer->isLogged() ? $this->customer->getFirstName() : '', 'width' => 'half', 'required' => true
		], [
			'name' => 'telephone', 'label' => $this->language->get('entry_telephone'), 'type' => 'tel', 'value' => $this->customer->isLogged() ? $this->customer->getTelephone() : '', 'width' => 'half', 'required' => true
		], [
			'name' => 'email', 'label' => $this->language->get('entry_email'), 'type' => 'email', 'value' => $this->customer->isLogged() ? $this->customer->getEmail() : '', 'width' => 'half', 'required' => false
		]];
		$data['custom_account'] = [];
		$data['custom_address'] = [];
		$data['countries'] = [];
		$data['zones'] = [];
		$data['show_country'] = false;
		$data['show_zone'] = false;
		$data['country_id'] = (int)$this->config->get('config_country_id');
		$data['zone_id'] = (int)$this->config->get('config_zone_id');
		$data['address_mode'] = 'address';
		$data['address_fields'] = [[
			'name' => 'city', 'label' => $this->language->get('entry_city'), 'value' => '', 'width' => 'half', 'required' => true
		], [
			'name' => 'address_1', 'label' => $this->language->get('entry_address_1'), 'value' => '', 'width' => 'full', 'required' => true
		]];
		$data['np_on'] = (bool)$this->config->get('module_storinka_np_status');
		$data['np_api'] = (bool)$this->config->get('module_storinka_np_key');
		$data['np_type'] = 'branch';
		$data['np_city'] = '';
		$data['np_city_ref'] = '';
		$data['np_wh_label'] = '';
		$data['comment'] = $this->session->data['comment'] ?? '';
		$data['comment_on'] = true;
		$data['coupon_on'] = (bool)$this->config->get('module_storinka_coupon');
		$data['coupon'] = $this->session->data['coupon'] ?? '';
		$data['agree'] = '';
		$data['accent'] = $this->config->get('module_storinka_accent') ?: '#9c3b2e';
		$data['radius'] = (int)($this->config->get('module_storinka_radius') ?: 14);
		$data['custom_css'] = (string)$this->config->get('module_storinka_css');
		$data['shipping_html'] = '';
		$data['payment_html'] = '';
		$data['items_html'] = '';
		$data['totals_html'] = '';
		$data['total_label'] = $this->currency->format($this->cart->getTotal(), $this->session->data['currency']);
		$data['config_json'] = json_encode([
			'save' => $this->url->link('extension/storinka/checkout/storinka.save', $base),
			'confirm' => $this->url->link('extension/storinka/checkout/storinka.confirm', $base),
			'cart' => $this->url->link('extension/storinka/checkout/storinka.cart', $base),
			'coupon' => $this->url->link('extension/storinka/checkout/storinka.coupon', $base),
			'login' => $this->url->link('extension/storinka/checkout/storinka.login', $base),
			'npCity' => $this->url->link('extension/storinka/checkout/storinka.npCity', $base),
			'npWarehouse' => $this->url->link('extension/storinka/checkout/storinka.npWarehouse', $base),
			'phoneMask' => true,
			'autoPay' => true,
			'np' => (bool)$this->config->get('module_storinka_np_key'),
			'npPlaceholder' => $this->language->get('text_warehouse'),
			'errorNetwork' => $this->language->get('error_network')
		], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
		$data['header'] = $this->load->controller('common/header');
		$data['footer'] = $this->load->controller('common/footer');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$this->response->setOutput($this->load->view('extension/storinka/checkout/storinka', $data));
	}

	public function save(): void {
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode(['error' => 'OpenCart 4 build refreshes methods on confirm. Use the 3.x package on ocStore 3.0.4.1.']));
	}

	public function confirm(): void { $this->save(); }
	public function cart(): void { $this->save(); }
	public function coupon(): void { $this->save(); }
	public function login(): void { $this->save(); }
	public function npCity(): void { $this->save(); }
	public function npWarehouse(): void { $this->save(); }
}
