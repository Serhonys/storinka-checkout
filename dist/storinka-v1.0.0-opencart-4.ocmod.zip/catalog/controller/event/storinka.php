<?php
namespace Opencart\Catalog\Controller\Extension\Storinka\Event;
class Storinka extends \Opencart\System\Engine\Controller {
	public function before(string &$route, array &$args): void {
		if (!$this->config->get('module_storinka_oc4_live')) {
			return;
		}
		if (!empty($this->request->get['storinka_off'])) {
			return;
		}
		if ((!$this->cart->hasProducts() && empty($this->session->data['vouchers'])) || (!$this->cart->hasStock() && !$this->config->get('config_stock_checkout')) || !$this->cart->hasMinimum()) {
			return;
		}
		$route = 'extension/storinka/checkout/storinka';
	}
}
