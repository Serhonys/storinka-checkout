<?php
namespace Opencart\Admin\Controller\Extension\Storinka\Module;
class Storinka extends \Opencart\System\Engine\Controller {
	public function index(): void {
		$this->load->language('extension/storinka/module/storinka');
		$this->document->setTitle($this->language->get('heading_title'));
		$data['breadcrumbs'] = [];
		$data['save'] = $this->url->link('extension/storinka/module/storinka.save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');
		$keys = ['status','guest','register','login','coupon','comment','cart_edit','image','autoselect','standard_link','phone_mask','auto_pay','hide_columns','no_address','rules','np_status','np_key','np_codes','np_courier','accent','radius','heading','button_text','css'];
		foreach ($keys as $key) {
			$name = 'module_storinka_' . $key;
			$data[$name] = $this->config->get($name);
		}
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/storinka/module/storinka', $data));
	}

	public function save(): void {
		$this->load->language('extension/storinka/module/storinka');
		$json = [];
		if (!$this->user->hasPermission('modify', 'extension/storinka/module/storinka')) {
			$json['error'] = $this->language->get('error_permission');
		}
		if (!$json) {
			$this->load->model('setting/setting');
			$this->model_setting_setting->editSetting('module_storinka', $this->request->post);
			$json['success'] = $this->language->get('text_success');
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function install(): void {
		$this->load->model('setting/event');
		if (method_exists($this->model_setting_event, 'deleteEventByCode')) {
			$this->model_setting_event->deleteEventByCode('storinka');
		}
		$this->model_setting_event->addEvent([
			'code'        => 'storinka',
			'description' => 'Storinka one-page checkout',
			'trigger'     => 'catalog/controller/checkout/checkout/before',
			'action'      => 'extension/storinka/event/storinka.before',
			'status'      => 1,
			'sort_order'  => 0
		]);
	}

	public function uninstall(): void {
		$this->load->model('setting/event');
		if (method_exists($this->model_setting_event, 'deleteEventByCode')) {
			$this->model_setting_event->deleteEventByCode('storinka');
		}
	}
}
