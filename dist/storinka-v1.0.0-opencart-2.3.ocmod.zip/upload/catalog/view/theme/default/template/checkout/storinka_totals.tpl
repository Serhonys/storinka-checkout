<ul class="sk-totals">
  <?php foreach ($totals as $total) { ?>
  <li class="<?php if ($total['code'] == 'total') { ?>is-grand<?php } ?>"><span><?php echo htmlspecialchars((string)($total['title']), ENT_QUOTES, 'UTF-8'); ?></span><span><?php echo htmlspecialchars((string)($total['text']), ENT_QUOTES, 'UTF-8'); ?></span></li>
  <?php } ?>
</ul>
