<?php if ($methods) { ?>
  <?php foreach ($methods as $method) { ?>
    <?php if ($method['quote']) { ?>
      <?php foreach ($method['quote'] as $quote) { ?>
      <label class="sk-choice <?php if ($quote['code'] == $selected) { ?>is-on<?php } ?>">
        <input type="radio" name="shipping_method" value="<?php echo htmlspecialchars((string)($quote['code']), ENT_QUOTES, 'UTF-8'); ?>" <?php if ($quote['code'] == $selected) { ?>checked<?php } ?>>
        <span><b><?php echo htmlspecialchars((string)($quote['title']), ENT_QUOTES, 'UTF-8'); ?></b><?php if ($method['title'] && $method['title'] != $quote['title']) { ?><small><?php echo htmlspecialchars((string)($method['title']), ENT_QUOTES, 'UTF-8'); ?></small><?php } ?></span>
        <span class="sk-price"><?php echo htmlspecialchars((string)($quote['text']), ENT_QUOTES, 'UTF-8'); ?></span>
      </label>
      <?php } ?>
    <?php } ?>
    <?php if ($method['error']) { ?><p class="sk-err"><?php echo htmlspecialchars((string)($method['error']), ENT_QUOTES, 'UTF-8'); ?></p><?php } ?>
  <?php } ?>
<?php } else { ?>
<p class="sk-muted"><?php echo htmlspecialchars((string)($empty), ENT_QUOTES, 'UTF-8'); ?></p>
<?php } ?>
