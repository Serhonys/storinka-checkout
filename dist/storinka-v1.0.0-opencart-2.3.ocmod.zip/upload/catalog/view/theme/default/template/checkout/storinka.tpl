<?php echo $header; ?>
<div class="sk" style="--sk-accent: <?php echo htmlspecialchars((string)($accent), ENT_QUOTES, 'UTF-8'); ?>; --sk-radius: <?php echo htmlspecialchars((string)($radius), ENT_QUOTES, 'UTF-8'); ?>px;">
  <div class="sk-wrap">
    <div class="sk-top">
      <div>
        <p class="sk-kicker">Storinka</p>
        <h1><?php echo htmlspecialchars((string)($heading_title), ENT_QUOTES, 'UTF-8'); ?></h1>
        <p class="sk-trust"><?php echo htmlspecialchars((string)($text_trust), ENT_QUOTES, 'UTF-8'); ?></p>
      </div>
      <?php if ($standard) { ?>
      <a class="sk-standard" href="<?php echo htmlspecialchars((string)($standard), ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string)($text_standard), ENT_QUOTES, 'UTF-8'); ?></a>
      <?php } ?>
    </div>
    <?php echo $content_top; ?>
    <form id="sk-form" action="<?php echo htmlspecialchars((string)($action), ENT_QUOTES, 'UTF-8'); ?>" method="post">
      <div class="sk-grid">
        <div class="sk-main">
          <?php if ($login_enabled) { ?>
          <section class="sk-card">
            <h2><?php echo htmlspecialchars((string)($text_login), ENT_QUOTES, 'UTF-8'); ?></h2>
            <div class="sk-login">
              <div class="sk-field" style="flex:1"><input id="sk-login-email" type="email" placeholder="Email" autocomplete="username"></div>
              <div class="sk-field" style="flex:1"><input id="sk-login-password" type="password" placeholder="Password" autocomplete="current-password"></div>
              <button type="button" class="sk-btn sk-ghost" id="sk-login-btn" style="width:auto;padding:0 18px;"><?php echo htmlspecialchars((string)($text_login), ENT_QUOTES, 'UTF-8'); ?></button>
            </div>
          </section>
          <?php } ?>

          <section class="sk-card">
            <h2><?php echo htmlspecialchars((string)($text_contact), ENT_QUOTES, 'UTF-8'); ?></h2>
            <div class="sk-fields">
              <?php foreach ($fields as $field) { ?>
              <div class="sk-field <?php if ($field['width'] == 'half') { ?>is-half<?php } ?>" data-field="<?php echo htmlspecialchars((string)($field['name']), ENT_QUOTES, 'UTF-8'); ?>">
                <label for="sk-<?php echo htmlspecialchars((string)($field['name']), ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string)($field['label']), ENT_QUOTES, 'UTF-8'); ?><?php if ($field['required']) { ?> *<?php } ?></label>
                <input id="sk-<?php echo htmlspecialchars((string)($field['name']), ENT_QUOTES, 'UTF-8'); ?>" type="<?php echo htmlspecialchars((string)($field['type']), ENT_QUOTES, 'UTF-8'); ?>" name="<?php echo htmlspecialchars((string)($field['name']), ENT_QUOTES, 'UTF-8'); ?>" value="<?php echo htmlspecialchars((string)($field['value']), ENT_QUOTES, 'UTF-8'); ?>" <?php if ($field['name'] == 'telephone') { ?>autocomplete="tel"<?php } ?> <?php if ($field['name'] == 'email') { ?>autocomplete="email"<?php } ?>>
              </div>
              <?php } ?>
              <?php foreach ($custom_account as $field) { ?>
              <div class="sk-field" data-field="custom-<?php echo htmlspecialchars((string)($field['id']), ENT_QUOTES, 'UTF-8'); ?>">
                <label><?php echo htmlspecialchars((string)($field['name']), ENT_QUOTES, 'UTF-8'); ?><?php if ($field['required']) { ?> *<?php } ?></label>
                <?php if ($field['type'] == 'select') { ?>
                <select name="custom_field[account][<?php echo htmlspecialchars((string)($field['id']), ENT_QUOTES, 'UTF-8'); ?>]">
                  <option value=""></option>
                  <?php foreach ($field['options'] as $option) { ?>
                  <option value="<?php echo htmlspecialchars((string)($option['custom_field_value_id']), ENT_QUOTES, 'UTF-8'); ?>" <?php if ($field['value'] == $option['custom_field_value_id']) { ?>selected<?php } ?>><?php echo htmlspecialchars((string)($option['name']), ENT_QUOTES, 'UTF-8'); ?></option>
                  <?php } ?>
                </select>
                <?php } elseif ($field['type'] == 'textarea') { ?>
                <textarea name="custom_field[account][<?php echo htmlspecialchars((string)($field['id']), ENT_QUOTES, 'UTF-8'); ?>]"><?php echo htmlspecialchars((string)($field['value']), ENT_QUOTES, 'UTF-8'); ?></textarea>
                <?php } else { ?>
                <input type="text" name="custom_field[account][<?php echo htmlspecialchars((string)($field['id']), ENT_QUOTES, 'UTF-8'); ?>]" value="<?php echo htmlspecialchars((string)($field['value']), ENT_QUOTES, 'UTF-8'); ?>">
                <?php } ?>
              </div>
              <?php } ?>
            </div>
            <?php if ($register_enabled) { ?>
            <label class="sk-check"><input type="checkbox" name="register" value="1"> <?php echo htmlspecialchars((string)($text_register), ENT_QUOTES, 'UTF-8'); ?></label>
            <div class="sk-field" data-field="password"><label><?php echo htmlspecialchars((string)($text_register), ENT_QUOTES, 'UTF-8'); ?></label><input type="password" name="password" autocomplete="new-password"></div>
            <?php } ?>
          </section>

          <section class="sk-card" id="sk-address" <?php if ($address_mode != 'address' && $address_mode != 'np_courier') { ?>style="display:none"<?php } ?>>
            <h2><?php echo htmlspecialchars((string)($text_shipping), ENT_QUOTES, 'UTF-8'); ?></h2>
            <div class="sk-fields">
              <?php if ($show_country) { ?>
              <div class="sk-field is-half" data-field="country_id">
                <label>Country</label>
                <select name="country_id">
                  <?php foreach ($countries as $country) { ?>
                  <option value="<?php echo htmlspecialchars((string)($country['country_id']), ENT_QUOTES, 'UTF-8'); ?>" <?php if ($country['country_id'] == $country_id) { ?>selected<?php } ?>><?php echo htmlspecialchars((string)($country['name']), ENT_QUOTES, 'UTF-8'); ?></option>
                  <?php } ?>
                </select>
              </div>
              <?php } else { ?>
              <input type="hidden" name="country_id" value="<?php echo htmlspecialchars((string)($country_id), ENT_QUOTES, 'UTF-8'); ?>">
              <?php } ?>
              <?php if ($show_zone) { ?>
              <div class="sk-field is-half" data-field="zone_id">
                <label>Region</label>
                <select name="zone_id">
                  <option value="0">—</option>
                  <?php foreach ($zones as $zone) { ?>
                  <option value="<?php echo htmlspecialchars((string)($zone['zone_id']), ENT_QUOTES, 'UTF-8'); ?>" <?php if ($zone['zone_id'] == $zone_id) { ?>selected<?php } ?>><?php echo htmlspecialchars((string)($zone['name']), ENT_QUOTES, 'UTF-8'); ?></option>
                  <?php } ?>
                </select>
              </div>
              <?php } else { ?>
              <input type="hidden" name="zone_id" value="<?php echo htmlspecialchars((string)($zone_id), ENT_QUOTES, 'UTF-8'); ?>">
              <?php } ?>
              <?php foreach ($address_fields as $field) { ?>
              <div class="sk-field <?php if ($field['width'] == 'half') { ?>is-half<?php } ?>" data-field="<?php echo htmlspecialchars((string)($field['name']), ENT_QUOTES, 'UTF-8'); ?>">
                <label><?php echo htmlspecialchars((string)($field['label']), ENT_QUOTES, 'UTF-8'); ?><?php if ($field['required']) { ?> *<?php } ?></label>
                <input type="text" name="<?php echo htmlspecialchars((string)($field['name']), ENT_QUOTES, 'UTF-8'); ?>" value="<?php echo htmlspecialchars((string)($field['value']), ENT_QUOTES, 'UTF-8'); ?>">
              </div>
              <?php } ?>
              <?php foreach ($custom_address as $field) { ?>
              <div class="sk-field">
                <label><?php echo htmlspecialchars((string)($field['name']), ENT_QUOTES, 'UTF-8'); ?></label>
                <input type="text" name="custom_field[address][<?php echo htmlspecialchars((string)($field['id']), ENT_QUOTES, 'UTF-8'); ?>]" value="<?php echo htmlspecialchars((string)($field['value']), ENT_QUOTES, 'UTF-8'); ?>">
              </div>
              <?php } ?>
            </div>
          </section>

          <section class="sk-card" id="sk-np" <?php if (!$np_on) { ?>style="display:none"<?php } ?>>
            <h2><?php echo htmlspecialchars((string)($text_np), ENT_QUOTES, 'UTF-8'); ?></h2>
            <div class="sk-seg">
              <button type="button" class="sk-textbtn <?php if ($np_type != 'postomat') { ?>is-on<?php } ?>" data-np-type="branch"><?php echo htmlspecialchars((string)($text_branch), ENT_QUOTES, 'UTF-8'); ?></button>
              <button type="button" class="sk-textbtn <?php if ($np_type == 'postomat') { ?>is-on<?php } ?>" data-np-type="postomat"><?php echo htmlspecialchars((string)($text_postomat), ENT_QUOTES, 'UTF-8'); ?></button>
            </div>
            <input type="hidden" name="np_type" id="sk-np-type" value="<?php echo htmlspecialchars((string)($np_type), ENT_QUOTES, 'UTF-8'); ?>">
            <div class="sk-field" data-field="np_city">
              <label><?php echo htmlspecialchars((string)($text_city), ENT_QUOTES, 'UTF-8'); ?></label>
              <input type="text" name="np_city" id="sk-np-city" value="<?php echo htmlspecialchars((string)($np_city), ENT_QUOTES, 'UTF-8'); ?>" autocomplete="off">
              <input type="hidden" name="np_city_ref" id="sk-np-city-ref" value="<?php echo htmlspecialchars((string)($np_city_ref), ENT_QUOTES, 'UTF-8'); ?>">
              <div id="sk-np-cities" class="sk-np-list" style="display:none"></div>
            </div>
            <div class="sk-field" id="sk-np-warehouse" data-field="np_wh">
              <label><?php echo htmlspecialchars((string)($text_branch), ENT_QUOTES, 'UTF-8'); ?></label>
              <?php if ($np_api) { ?>
              <select name="np_wh" id="sk-np-wh"><option value="">—</option></select>
              <input type="hidden" name="np_wh_label" id="sk-np-wh-label" value="<?php echo htmlspecialchars((string)($np_wh_label), ENT_QUOTES, 'UTF-8'); ?>">
              <?php } else { ?>
              <input type="text" name="np_wh_label" id="sk-np-wh-label" value="<?php echo htmlspecialchars((string)($np_wh_label), ENT_QUOTES, 'UTF-8'); ?>">
              <?php } ?>
            </div>
          </section>

          <section class="sk-card">
            <h2><?php echo htmlspecialchars((string)($text_shipping), ENT_QUOTES, 'UTF-8'); ?></h2>
            <div id="sk-shipping-box"><?php echo $shipping_html; ?></div>
          </section>
          <section class="sk-card">
            <h2><?php echo htmlspecialchars((string)($text_payment), ENT_QUOTES, 'UTF-8'); ?></h2>
            <div id="sk-payment-box"><?php echo $payment_html; ?></div>
          </section>
          <?php if ($comment_on) { ?>
          <section class="sk-card">
            <h2><?php echo htmlspecialchars((string)($text_comment), ENT_QUOTES, 'UTF-8'); ?></h2>
            <div class="sk-field"><textarea name="comment"><?php echo htmlspecialchars((string)($comment), ENT_QUOTES, 'UTF-8'); ?></textarea></div>
          </section>
          <?php } ?>
          <?php if ($agree) { ?>
          <label class="sk-check" data-field="agree"><input type="checkbox" name="agree" value="1"> <?php echo $agree; ?></label>
          <?php } ?>
        </div>
        <aside class="sk-summary">
          <section class="sk-card">
            <h2><?php echo htmlspecialchars((string)($heading_title), ENT_QUOTES, 'UTF-8'); ?></h2>
            <div id="sk-items"><?php echo $items_html; ?></div>
            <?php if ($coupon_on) { ?>
            <div class="sk-field" data-field="coupon" style="margin-top:12px">
              <label><?php echo htmlspecialchars((string)($text_coupon), ENT_QUOTES, 'UTF-8'); ?></label>
              <div class="sk-row">
                <input type="text" id="sk-coupon" value="<?php echo htmlspecialchars((string)($coupon), ENT_QUOTES, 'UTF-8'); ?>">
                <button type="button" class="sk-textbtn" id="sk-coupon-btn" style="width:auto">OK</button>
              </div>
            </div>
            <?php } ?>
            <div id="sk-totals"><?php echo $totals_html; ?></div>
            <button type="submit" class="sk-btn" id="sk-submit"><?php echo htmlspecialchars((string)($button_confirm), ENT_QUOTES, 'UTF-8'); ?> · <span id="sk-submit-sum"><?php echo htmlspecialchars((string)($total_label), ENT_QUOTES, 'UTF-8'); ?></span></button>
            <div id="sk-paymount" class="sk-paymount"></div>
          </section>
        </aside>
      </div>
    </form>
    <?php echo $content_bottom; ?>
  </div>
</div>
<?php if ($custom_css) { ?>
<style><?php echo $custom_css; ?></style>
<?php } ?>
<script>window.StorinkaConfig = <?php echo $config_json; ?>;</script>
<?php echo $footer; ?>
