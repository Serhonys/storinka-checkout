<?php if ($methods) { ?>
  <?php foreach ($methods as $method) { ?>
  <label class="sk-choice <?php if ($method['code'] == $selected) { ?>is-on<?php } ?>">
    <input type="radio" name="payment_method" value="<?php echo htmlspecialchars((string)($method['code']), ENT_QUOTES, 'UTF-8'); ?>" <?php if ($method['code'] == $selected) { ?>checked<?php } ?>>
    <span><b><?php echo htmlspecialchars((string)($method['title']), ENT_QUOTES, 'UTF-8'); ?></b></span>
  </label>
  <?php } ?>
<?php } else { ?>
<p class="sk-muted"><?php echo htmlspecialchars((string)($empty), ENT_QUOTES, 'UTF-8'); ?></p>
<?php } ?>
