<?php foreach ($products as $product) { ?>
<div class="sk-item">
  <?php if ($product['thumb']) { ?><img src="<?php echo htmlspecialchars((string)($product['thumb']), ENT_QUOTES, 'UTF-8'); ?>" alt=""><?php } else { ?><span class="sk-thumb"></span><?php } ?>
  <div>
    <p class="sk-name"><?php echo htmlspecialchars((string)($product['name']), ENT_QUOTES, 'UTF-8'); ?></p>
    <?php if ($product['option']) { ?><p class="sk-muted"><?php echo htmlspecialchars((string)($product['option']), ENT_QUOTES, 'UTF-8'); ?></p><?php } ?>
    <?php if ($edit) { ?>
    <div class="sk-qty">
      <button type="button" data-sk-qty="-1" data-cart="<?php echo htmlspecialchars((string)($product['cart_id']), ENT_QUOTES, 'UTF-8'); ?>">−</button>
      <span data-sk-qval><?php echo htmlspecialchars((string)($product['quantity']), ENT_QUOTES, 'UTF-8'); ?></span>
      <button type="button" data-sk-qty="1" data-cart="<?php echo htmlspecialchars((string)($product['cart_id']), ENT_QUOTES, 'UTF-8'); ?>">+</button>
      <button type="button" class="sk-textbtn" data-sk-remove data-cart="<?php echo htmlspecialchars((string)($product['cart_id']), ENT_QUOTES, 'UTF-8'); ?>">×</button>
    </div>
    <?php } else { ?>
    <p class="sk-muted">× <?php echo htmlspecialchars((string)($product['quantity']), ENT_QUOTES, 'UTF-8'); ?></p>
    <?php } ?>
  </div>
  <div><?php echo htmlspecialchars((string)($product['total']), ENT_QUOTES, 'UTF-8'); ?></div>
</div>
<?php } ?>
